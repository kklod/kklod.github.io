﻿define(['connectionManager', 'itemrepository'], function (connectionManager, itemRepository) {
    'use strict';
});